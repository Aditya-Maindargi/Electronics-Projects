int buzzer = 3 ; 

int dot = 200 ; 
int dash = 600 ; 

void setup() {
  
  pinMode(buzzer , OUTPUT);

}

void loop() {

  // A = .-
  
  digitalWrite(buzzer , HIGH);
  delay(dot);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dash);

  digitalWrite(buzzer , LOW);
  delay(600);


  // D = -..

  digitalWrite(buzzer , HIGH);
  delay(dash);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dot);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dot);

  digitalWrite(buzzer , LOW);
  delay(600);


  // I = ..

  digitalWrite(buzzer , HIGH);
  delay(dot);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dot);

  digitalWrite(buzzer , LOW);
  delay(600);


  // T = -

  digitalWrite(buzzer , HIGH);
  delay(dash);

  digitalWrite(buzzer , LOW);
  delay(600);


  // Y = -.--

  digitalWrite(buzzer , HIGH);
  delay(dash);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dot);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dash);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dash);

  digitalWrite(buzzer , LOW);
  delay(600);


  // A = .-

  digitalWrite(buzzer , HIGH);
  delay(dot);

  digitalWrite(buzzer , LOW);
  delay(dot);

  digitalWrite(buzzer , HIGH);
  delay(dash);

  digitalWrite(buzzer , LOW);
  delay(3000);

}